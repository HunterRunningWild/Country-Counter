# Country Counter — iOS‑style (Single‑File App)

This zip contains a single `index.html` that runs entirely offline. 
Open it in Safari and "Add to Home Screen" for an app-like experience.

## Quick Deploy: GitHub Pages (2–3 minutes)
1. Go to https://github.com/new and create a repository named `country-counter` (public).
2. Click **Add file → Upload files**, drag in `index.html`, then **Commit**.
3. Go to **Settings → Pages**.
   - **Build and deployment**: Source = **Deploy from a branch**.
   - Branch = **main**, Folder = **/** (root). Save.
4. Wait ~30 seconds. Your site will appear as:
   `https://<your-username>.github.io/country-counter/`
5. Open that link on your iPhone → Share → **Add to Home Screen**.

## Netlify (one‑click)
1. Go to https://app.netlify.com/drop
2. Drag in the `index.html` file. Done. Netlify gives you a live URL.

---

If you want a custom app icon/name, open `index.html` and search for:
- `<title>Country Counter — iOS-style</title>` to change the name.
